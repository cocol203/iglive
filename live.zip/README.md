# liveig
git clone https://github.com/ikhsanh/liveig/
cd liveig
unzip live.zip
nano live.php
edit username sama password mu
tambahkan link video ke 'link video'
php live.php
