<?php
set_time_limit(0);
date_default_timezone_set('UTC');
require 'vendor/autoload.php';

echo "# ################################################ #\n";
echo "# \t\tInstagram Live Custom\t\t   #\n";
echo "# \t\t     Version 1.0\t\t   #\n";
echo "# ################################################ #\n\n";

First:
echo "[+] Masukkan username anda : "; $username = trim(fgets(STDIN));
echo "[+] Masukkan password anda : "; $password = trim(fgets(STDIN));

if($username && $password) {
	echo "[!] Memulai login... ";
	$ig = new \InstagramAPI\Instagram(false, false);
	try {
	    $ig->login($username, $password);
	    echo "OK !\n\n";
	} catch (\Exception $e) {
	    echo '[?] Something went wrong: '.$e->getMessage()."\n";
	    exit(0);
	}
	echo "[+] Masukkan live instagram link (isdb.pw / dkk) : "; $linkvideo = trim(fgets(STDIN));
	try {
		echo "\n===Comment===\n";
		$ffmpegPath = null;
	    $ffmpeg = \InstagramAPI\Media\Video\FFmpeg::factory($ffmpegPath);
	    $stream = $ig->live->create();
	    $broadcastId = $stream->getBroadcastId();
	    $ig->live->start($broadcastId);
	    $streamUploadUrl = $stream->getUploadUrl();
	    $broadcastProcess = $ffmpeg->runAsync(sprintf(
	        '-rtbufsize 256M -re -i %s -acodec libmp3lame -ar 44100 -b:a 128k -pix_fmt yuv420p -profile:v baseline -s 720x1280 -bufsize 6000k -vb 400k -maxrate 1500k -deinterlace -vcodec libx264 -preset veryfast -g 30 -r 30 -f flv %s',
	        \Winbox\Args::escape($linkvideo),
	        \Winbox\Args::escape($streamUploadUrl)
	    ));

	    $lastCommentTs = 0;
	    $lastLikeTs = 0;
	    do {
	    	$commentsResponse = $ig->live->getComments($broadcastId, $lastCommentTs);
	        $systemComments = $commentsResponse->getSystemComments();
	        $comments = $commentsResponse->getComments();
	        if (!empty($systemComments)) {
	            $lastCommentTs = $systemComments[0]->getCreatedAt();
	        }
	        if (!empty($comments) && $comments[0]->getCreatedAt() > $lastCommentTs) {
	            $lastCommentTs = $comments[0]->getCreatedAt();
	        }
        	if(!empty($comments)) {
        		foreach ($comments as $comment) {
        			echo "@".$comment->getUser()->getUsername()." comment. ' ".$comment->getText()." '\n";
        		}
        	}
	        $heartbeatResponse = $ig->live->getHeartbeatAndViewerCount($broadcastId);
	        if ($heartbeatResponse->isIsPolicyViolation() && (int) $heartbeatResponse->getIsPolicyViolation() === 1) {
	            echo 'Instagram has flagged your content as a policy violation with the following reason: '.($heartbeatResponse->getPolicyViolationReason() == null ? 'Unknown' : $heartbeatResponse->getPolicyViolationReason())."\n";
	            if (true) {
	                $ig->live->getFinalViewerList($broadcastId);
	                $ig->live->end($broadcastId, true);
	                exit(0);
	            }
	            $ig->live->resumeBroadcastAfterContentMatch($broadcastId);
	        }
	        $likeCountResponse = $ig->live->getLikeCount($broadcastId, $lastLikeTs);
	        $lastLikeTs = $likeCountResponse->getLikeTs();
	        $ig->live->getJoinRequestCounts($broadcastId);
	        sleep(2);
	    } while ($broadcastProcess->isRunning());
	    $ig->live->getFinalViewerList($broadcastId);
	    $ig->live->end($broadcastId);
	    $ig->live->addToPostLive($broadcastId);
    } catch (\Exception $e) {
	    echo 'Something went wrong: '.$e->getMessage()."\n";
	}
} else {
	echo "\n";
	goto First;
}